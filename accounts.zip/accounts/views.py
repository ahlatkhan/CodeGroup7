from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from music.models import Alu3 as FormModel, UserForm
from django.contrib.auth.models import User


def home(request):
    return render(request, 'accounts/home.html')



def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            print('helllo\n\n\n\n\n')
            form.save()

            # saving data in form
            var  = request.POST.get('username')
            obj = User.objects.get(username=var).pk
            x = FormModel(uid=obj)
            x.save()  # cnic saved table form 2

            # saving user id  and form id in UserForm Table

            obj2 = FormModel.objects.get(uid=obj)
            x = UserForm(uid=obj, fid=obj2.id)
            x.save()  # both ids saved successfully
            return redirect('/accounts/login')
    else:
        form = UserCreationForm()
        args = {'form': form}
        return render(request, 'accounts/reg_form.html',args)