from django.shortcuts import redirect
from music.models import UserForm


def login_redirect(request):
    return redirect('/accounts/login')

def check(request):
    if request.user.is_staff:
        print('is_staff')
        return redirect('music/alumni')
    else:
        obj2 = UserForm.objects.get(uid=str(request.session['id']))
        print('is authenticated')
        request.session['form_id'] = obj2.fid
        print (request.session['form_id'])
        return redirect('/music/home')