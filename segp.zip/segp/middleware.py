import re
from django.conf import settings
from django.contrib.auth.models import User
from django.contrib.auth import logout
from music.models import UserForm
from django.shortcuts import redirect


EXEMPT_URLS = [re.compile(settings.LOGIN_URL.lstrip('/'))]
ALUMNI_EXEMPT_URL = [re.compile(settings.LOGIN_URL.lstrip('/'))]
if hasattr(settings, 'LOGIN_EXEMPT_URLS'):
    EXEMPT_URLS += [re.compile(url) for url in settings.LOGIN_EXEMPT_URLS]
if hasattr(settings, 'ALUMNI_EXEMPT_URLS'):
    ALUMNI_EXEMPT_URL += [re.compile(url) for url in settings.ALUMNI_EXEMPT_URL]

class LoginRequiredMiddleware:

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):
        assert hasattr(request, 'user')
        path = request.path_info.lstrip('/')
        print(path)
        request.session['id'] = request.user.id
        if request.user.is_authenticated and not request.user.is_staff:
            obj2 = UserForm.objects.get(uid=str(request.session['id']))
            request.session['pathinfo'] = "/music/form/" + str(obj2.fid)+ "/"
            request.session['path_d']='/'+path

        # s = request.session['id']
        # obj2 = UserForm.objects.get(uid=int(s))
        # request.session['form_id'] = obj2.fid
        # print(request.session['id'])
        # print('Middleware\n\n\n'+request.session['form_id']+'\n\n\n')


        alumni_url_is_exempt = any(url.match(path) for url in ALUMNI_EXEMPT_URL)
        print('\n\n')
        print(alumni_url_is_exempt)
        print('hello')
        print('\n\n')
        # if alumni_url_is_exempt == True and not request.user.is_staff and request.user.is_authenticated:
        #     print('inthe')
        #     if not any(url.match(path) for url in ALUMNI_EXEMPT_URL):
        #         print('redirectings')
        #         return redirect(settings.LOGIN_URL)
        # elif request.user.is_authenticated and not request.user.is_staff and not alumni_url_is_exempt:
        #     print('redirectinga')
        #     return redirect(settings.LOGIN_REDIRECT_URL)

        if not request.user.is_authenticated:
            if not any(url.match(path) for url in EXEMPT_URLS):
                return redirect(settings.LOGIN_URL)
        url_is_exempt = any(url.match(path) for url in EXEMPT_URLS)
        # print('\n\n\n\n\n\nd')
        print(url_is_exempt)
        # print('\n\n\n\n\n\n')

        if path == 'accounts/logout':
            logout(request)
        if request.user.is_authenticated and url_is_exempt:
            return redirect(settings.LOGIN_REDIRECT_URL)

        elif request.user.is_authenticated or url_is_exempt:
            return None
        else:
            return redirect(settings.LOGIN_REDIRECT_URL)
