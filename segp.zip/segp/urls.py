from django.conf.urls import include, url
from django.urls import path
from django.contrib.auth import views as auth_views
from django.contrib import admin
from segp import views
from segp.views import login_redirect

urlpatterns = [
    path('', login_redirect, name='login_redirect'),
    path('admin/', admin.site.urls),
    path('music/', include('music.url')),
    path('accounts/', include('accounts.urls')),
    path('check', views.check, name='check'),
    path('logout/',auth_views.LogoutView.as_view(),name='logout')
]
