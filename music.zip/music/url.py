from django.contrib import admin
from django.urls import path
from django.contrib.auth.views import login

from . import views

urlpatterns = [

    #     # /music
    #     path('', views.IndexView.as_view(), name ='index'),
    #
    # #   /music/69
    # #     path('<int:album_id>/', views.DetailsView.as_view(), name='details'),
    path('home/', views.home, name='alumnihomes'),

    path('analysis/', views.analysis, name='alumnihomes'),
    #   /music/form
    path('form/', views.NewForm.as_view(), name='form'),

    #     # /music/form/primaryKey
    #     path('form/<pk>/', views.UpdateForm.as_view(), name='updateform'),
    path('form/<pk>/', views.UpdateForm.as_view(), name='get_form'),
    path('home/music/get_form/<pk>/', views.get_form, name='get_form'),

    path('submited/', views.submited, name='submited'),

    # #     /music/registration
    # path('registration/', views.UserRegistration.as_view(), name='registration'),
    #
    #     # music/login/
    #     # path('login/', views.Login.as_view(), name='login'),
    #
    #
    # # music/alumni/form/54
    path('alumni/form/<pk>/', views.UpdateForm.as_view(), name='alumni_update'),

    path('alumni/deleteForm/<pk>/', views.DeleteForm.as_view(), name='alumni_delete'),
    #
    #    music/alumni/
    path('alumni/', views.Alumni.as_view(), name='alumni'),

    #     music/projects/add_project/
    path('projects/add_project/', views.NewProject.as_view(), name=''),

    #  music/projects/
    path('projects/', views.Projects.as_view(), name='projects'),

    # music/projects/update_project/2/
    path('projects/update_project/<pk>/', views.UpdateProject.as_view(), name='login'),


    path('projects/deleteProject/<pk>/', views.DeleteProject.as_view(), name='project_delete'),

    #  music/workshops&trainings/
    path('workshops&trainings/', views.Workshops.as_view(), name='workshops&trainings'),

    #  music/workshops&trainings/addNew/
    path('workshops&trainings/addNew', views.NewWorkshop.as_view(), name='NewWorkshop'),

    #  music/workshops&trainings/2/
    path('workshops&trainings/update_workshops&training/<pk>/', views.UpdateWorkshop.as_view(), name='UpdateWorkshop'),
    path('workshops&trainings/delete_workshops&training/<pk>/', views.DeleteWorkshop.as_view(), name='DeleteWorkshop'),

    # # music/f/
    # path('f/', views.Form.as_view(), name='f'),

    #
    # #   /music/69/favourites
    #     path('<int:album_id>/favourites/', views.favourites, name='fav'),
    #
    # #   /music/69/display
    #     path('1/display/', views.display, name='display'),
]
