from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.models import AnonymousUser
from django.contrib.auth.models import User
from django.utils.decorators import method_decorator
from django.views import generic
from .models import Alu3 as FormModel,  Project, Workshop, UserForm
from django.shortcuts import render, redirect
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic import TemplateView
from django.contrib.auth.views import redirect_to_login
from datetime import date
from django.urls import reverse_lazy

@method_decorator(login_required, name='dispatch')
class IndexView(generic.ListView):
    template_name = 'music/projects.html'



class DetailsView(generic.ListView):
    template_name = 'music/details.html'
#
# @method_decorator(login_required, name='dispatch')
# class Form(TemplateView):
#     template_name = 'music/alumni_login.html'
#
#
#     def get(self, request, *args, **kwargs):
#         form = AluminiForm()
#
#         post=Alu3.objects.all()
#
#         args= {'form':form, 'post': post}
#         return render(request, self.template_name, args)
#
#     def post(self, request):
#
#         form= AluminiForm(request.POST)
#
#         post = FormModel.objects.all()
#
#         # if form.is_valid():
#
#         form.save()
#         # text = form.cleaned_data['email']
#
#
#         args = {'form': form}
#
#         return render(request, self.template_name, args)
#         # else:
#         #     return render(request, 'music/workshops.html')
#
#
# @method_decorator(login_required, name='dispatch')
# class Register(TemplateView):
#     template_name = 'music/registeration.html'
#
#     def get(self, request, *args, **kwargs):
#         form1 = Registration()
#
#         args = {'form': form1,}
#         return render(request, self.template_name, args)
#
#     def post(self, request):
#
#         form = Registration(request.POST)
#
#         if form.is_valid():
#
#             form.save()
#             return redirect('/music/login')
#         else:
#             return render(request, self.template_name)
#
#

# class Login(TemplateView):
#
#     template_name = 'music/login.html'
#
#     def get(self, request, *args, **kwargs):
#
#         form = LoginForm()
#
#         args = {'form': form, }
#         return render(request, self.template_name, args)
#
#     def post(self, request):
#
#         form = LoginForm(request.POST)
#
#         return redirect('/music/projects')








# @method_decorator(login_required, name='dispatch')

class NewForm(CreateView):
    model = FormModel
    fields = ['name', 'cnic', 'year', 'cohort_number', 'career', 'email', 'address', 'current_work', 'achievements', 'goals']


def user_passes_test(request):
    print('helo')
# @method_decorator(login_required, name='dispatch')
class UpdateForm(UpdateView):
    model = FormModel
    fields = ['name', 'cnic', 'year', 'cohort_number', 'email', 'address', 'career', 'dob', 'current_work', 'achievements',
              'goals']
class DeleteForm(DeleteView):

    model = FormModel

    success_url =reverse_lazy('alumni')


        # if request.user.is_authenticated:
        #     self.object = self.get_object()
        #     return self.uid == request.user.id
        # return False

    # def dispatch(self, request, *args, **kwargs):
    #     if not self.user_passes_test(request):
    #         return redirect_to_login(request.get_full_path())
    #     return super(ProfileUpdate, self).dispatch(
    #         request, *args, **kwargs)


    # pk = self.kwargs.get('pk')
    # def get_context_data(self, **kwargs):
    #     context = super(UpdateForm, self).get_context_data(**kwargs)
    #     return context
        # pk = self.kwargs.get('pk')
        # obj2 = UserForm.objects.get(uid=pk)
        # s = obj2.fid
        # print (str(request.session['form_id']) + '\n\n\n\n\n\n' + str(request.session['id']) + '\n\n\n' + s)
        # print(int(s) + int(request.session['form_id']))
        # if int(request.session['form_id']) == int(s):
        #     print ('in condition' + str(request.session['form_id']) + '\n\n\n\n\n\n' + str(
        #         request.session['id']) + '\n\n\n' + s)
        #     print(int(s) + int(request.session['form_id']))
        #     return redirect('/music/form/' + str(s))
        # else:
        #     return redirect('/logout')

    #     model = FormModel
    #     fields = ['name', 'cnic', 'year', 'cohort_number', 'email', 'address', 'career', 'current_work', 'achievements',
    #               'goals']
    #     return render(request, "music/index.html")


@method_decorator(login_required, name='dispatch')
class NewProject(CreateView):
    model = Project
    fields = ['project_name', 'project_year', 'cohort_number', 'coordinator_name', 'project_description', 'starting_date', 'ending_date', 'project_feedback',
              'success_rate']
@method_decorator(login_required, name='dispatch')
class UpdateProject(UpdateView):
    model = Project
    fields = ['project_name', 'project_year', 'cohort_number', 'coordinator_name', 'project_description', 'starting_date', 'ending_date', 'project_feedback',
              'success_rate']

class DeleteProject(DeleteView):

    model = Project

    success_url =reverse_lazy('projects')


@method_decorator(login_required, name='dispatch')
class UserRegistration(TemplateView):

    template_name = 'music/registeration.html'
    # form_class = NewUser

    def get(self, request, *args, **kwargs):

        form = self.form_class(None)

        return render(request,self.template_name, {'form':form})

    def post(self,request):

        form= self.form_class(request.POST)
        if form.is_valid():


# saving user in user table
            user= form.save(commit=False)
            username=form.cleaned_data['username']
            password= form.cleaned_data['password']
            user.set_password(password)
            user.save()  #user saved successfully


# saving data in form

            x=FormModel(cnic=request.POST.get("first_name"), dob='0000-00-00')
            x.save()  #cnic saved table form 2


# saving user id  and form id in UserForm Table

            registring = request.POST.get("username")
            obj = User.objects.get(username=registring)
            obj2 = FormModel.objects.get(cnic=request.POST.get("first_name"))
            x= UserForm(uid=obj.id,fid=obj2.id)
            x.save()  #both ids saved successfully

        return redirect('/music/login')

#
# view table of alumni
#
# @method_decorator(login_required, name='dispatch')


class Alumni(TemplateView):

    template_name = 'music/alumni.html'

    def get(self, request, *args, **kwargs):

        form = FormModel.objects.all()

        args = {'form': form, }

        return render(request, self.template_name, args)
#
# @method_decorator(login_required, name='dispatch')

class Projects(TemplateView):
    template_name = 'music/projects.html'

    def get(self, request, *args, **kwargs):
        form = Project.objects.all()

        args = {'form': form, }


        return render(request, self.template_name, args)

class Workshops(TemplateView):
    template_name = 'music/workshops.html'

    def get(self, request, *args, **kwargs):
        form = Workshop.objects.all()

        args = {'form': form, }


        return render(request, self.template_name, args)


class NewWorkshop(CreateView):
    model = Workshop
    fields = ['events_name', 'event_category', 'instructor_name', 'starting_date', 'ending_date', 'success_rate', 'event_description', 'event_feedback']


class UpdateWorkshop(UpdateView):
    model = Workshop
    fields = ['events_name', 'event_category', 'instructor_name', 'starting_date', 'ending_date', 'success_rate', 'event_description', 'event_feedback']

class DeleteWorkshop(DeleteView):

    model = Workshop

    success_url =reverse_lazy('workshops&trainings')



# def details(request, album_id):
#     album = get_object_or_404(Albums, pk=album_id)
#     a = "shah"
#     return render(request, 'music/details.html', {'album': album, 'shah' : a})


# class AlumniForm(TemplateView):
#
#     template_name = 'music/AlumniForm.html'
#
#     def get(self, request, *args, **kwargs):
#
#         form = FormModel
#         return render(request,self.template_name, {'form': form})
#










































# from django.shortcuts import render, get_object_or_404
# from .models import Albums, Songs
#
#
# def index(request):
#     all_albums = Albums.objects.all()
#     context = {
#         'all_albums': all_albums,
#     }
#     return render(request, 'music/index.html', context)
#
#
# def details(request, album_id):
#     album = get_object_or_404(Albums, pk=album_id)
#     a = "shah"
#     return render(request, 'music/details.html', {'album': album, 'shah' : a})
#
#
# def favourites(request, album_id):
#     album = get_object_or_404(Albums, pk=album_id)
#
#     try:
#         selected_songs = album.songs_set.get(pk=request.POST['song'])
#     except (KeyError, Songs.DoesNotExist):
#         return render(request, 'music/details.html', {'album': album, 'error_message': 'Song does not exist'})
#     else:
#
#         selected_songs.is_fav = True
#         selected_songs.save()
#         return render(request, 'music/details.html', {'album': album})
#
#
# def display(request):
#     return render(request, 'music/display.html')

# def getuserid(request):
#     username = request.POST['username']
#     obj = User.objects.get(username=username).id


def get_form(request,pk):
    if request.user.is_staff:
        return redirect('/music/alumni')
    else:
        obj2 = UserForm.objects.get(uid=pk)
        s = obj2.fid
        print (str(request.session['form_id'])+'\n\n\n\n\n\n'+str(request.session['id']) +'\n\n\n'+ s)
        print(int(s)+int(request.session['form_id']))
        if int(request.session['form_id']) == int(s):
            print ('in condition'+str(request.session['form_id']) + '\n\n\n\n\n\n' + str(request.session['id']) + '\n\n\n' + s)
            print(int(s) + int(request.session['form_id']))
            return redirect('/music/form/'+str(s))
        else:
            return redirect('/logout')

def home(request):
    return render(request,'music/alumni_home.html')

def calculate_age(born):
    today = date.today()
    return today.year - born.year - ((today.month, today.day) < (born.month, born.day))

def analysis(request):
    obj2 = FormModel.objects.values('dob')
    x=[]
    thirteen_fifteen=0
    sixteen_eighteen=0
    nineteen_twentyone=0
    twentytwo_twentyfour=0


    for n in obj2:

        # print(calculate_age(n['dob']))

        x.append(calculate_age(n['dob']))


        # print(n['dob'])

    for i in range(len(x)):
        # print(x[i])
        if x[i] is 19 or x[i] is 20 or x[i] is 21:
            nineteen_twentyone=nineteen_twentyone+1
        elif x[i] is 16 or x[i] is 17 or x[i] is 18:
            sixteen_eighteen = sixteen_eighteen + 1
        elif x[i] is 22 or x[i] is 23 or x[i] is 24:
            twentytwo_twentyfour = twentytwo_twentyfour + 1
        elif x[i] is 13 or x[i] is 14 or x[i] is 15:
            thirteen_fifteen = thirteen_fifteen + 1

    context = {
            'sixteen_eighteen': sixteen_eighteen,
            'nineteen_twentyone': nineteen_twentyone,
            'twentytwo_twentyfour': twentytwo_twentyfour,
             'thirteen_fifteen': thirteen_fifteen,
        }

    return render(request,'music/alumni-analysis.html', context)


def submited(request):
    return render(request,'music/submited.html')

