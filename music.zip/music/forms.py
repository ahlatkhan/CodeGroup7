from django import forms
from .models import Form2 as FormModel, Year
from django.contrib.auth.models import User
from crispy_forms.helper import FormHelper


class AluminiForm(forms.ModelForm):
    year = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Year'}))
    cohort_number = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Cohort No'}))
    address = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Address'}))
    career = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'carear'}))
    current_work = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'max 300 words'}))
    achievements = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'max 300 words'}))
    goals = forms.CharField(widget=forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'max 300 words'}))


    class Meta:
        model = FormModel
        fields = ('year', 'cohort_number', 'address', 'career', 'current_work', 'achievements', 'goals')


    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['year'].queryset = Year.objects.all()

class Registration(forms.ModelForm):
    name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'name'}))
    cnic = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'CNIC'}))
    dob = forms.DateField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Date of Birth mm/dd/yy'}))
    email = forms.EmailField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Email'}))

    class Meta:
        model = FormModel
        fields = ('name', 'cnic', 'dob', 'email')

        #

class NewUser(forms.ModelForm):

    helper = FormHelper()
    helper.form_show_labels = False




    class Meta:

        model = User
        fields = ['username', 'email', 'password', 'first_name']

class LoginForm(forms.Form):

    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'username'}))
    password = forms.CharField(widget=forms.TextInput(attrs={'type': 'password', 'class': 'form-control', 'placeholder': 'password'}))
