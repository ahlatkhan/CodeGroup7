from django.db import models
from django.urls import reverse
from django.contrib.auth.models import User

class Albums(models.Model):
    artist = models.CharField(max_length=255)
    album_title = models.CharField(max_length=255)
    genre = models.CharField(max_length=100)

    def __str__(self):
        return self.artist + '-' + self.album_title


class Songs(models.Model):
    album = models.ForeignKey(Albums, on_delete=models.CASCADE)
    file_type = models.CharField(max_length=10)
    song_title = models.CharField(max_length=100)
    is_fav = models.BooleanField(default=False)

    def __str__(self):
        return self.song_title


class Users(models.Model):
    username = models.CharField(max_length=200)
    password = models.CharField(max_length=200)


class Alu3(models.Model):
    uid = models.CharField(max_length=100)
    name = models.CharField(max_length=255)
    cnic = models.CharField(max_length=15)
    dob = models.DateField(max_length=13, default='2015-04-04')
    email = models.EmailField(max_length=155)
    address = models.CharField(max_length=200)
    current_work = models.TextField(max_length=500)
    achievements = models.TextField(max_length=500)
    goals = models.TextField(max_length=500)
    year = models.CharField(max_length=4)
    cohort_number = models.CharField(max_length=4)
    career = models.CharField(max_length=20)

    def get_absolute_url(self):
        return reverse('submited')


# class Form2(models.Model):
#     name = models.CharField(max_length=255)
#     cnic = models.CharField(max_length=15)
#     # dob = models.DateField(max_length=13)
#     email = models.EmailField(max_length=155)
#     address = models.CharField(max_length=200)
#     current_work = models.TextField(max_length=500)
#     achievements =  models.TextField(max_length=500, default='2014')
#     goals = models.TextField(max_length=500)
#     year = models.CharField(max_length=4)
#     cohort_number = models.CharField(max_length=4)
#     career = models.CharField(max_length=20)
#     MY_CHOICES = (
#         ('2014', '2014'),
#         ('2015', '2015'),
#         ('2016', '2016'),
#         ('2017', '2017'),
#     )
#
#     year = models.CharField(max_length=4, choices=MY_CHOICES)
#
#     MY_CHOICES = (
#         ('1', '1'),
#         ('2', '2'),
#         ('3', '3'),
#         ('4', '4'),
#     )
#
#     cohort_number = models.CharField(max_length=4, choices=MY_CHOICES)
#
#     MY_CHOICES = (
#         ('Student', 'Student'),
#         ('Under-Grad', 'Under-Grad'),
#         ('Grad', 'Grad'),
#         ('Employed', 'Employed'),
#         ('Self-Employed', 'Self-Employed'),
#
#     )
#
#     career = models.CharField(max_length=20, choices=MY_CHOICES)
#
#     def get_absolute_url(self):
#         return reverse('alumni')


class Project(models.Model):
    project_name = models.CharField(max_length=255)
    project_year = models.CharField(max_length=10)
    cohort_number = models.CharField(max_length=10)
    coordinator_name = models.CharField(max_length=255)
    project_description = models.TextField(max_length=500)
    starting_date = models.DateField(max_length=13)
    ending_date = models.DateField(max_length=13)
    project_feedback = models.TextField(max_length=500)
    MY_CHOICES = (
        ('10', '10'),
        ('20', '20'),
        ('30', '30'),
        ('40', '40'),
        ('50', '50'),
        ('60', '60'),
        ('70', '70'),
        ('80', '80'),
        ('90', '90'),
        ('100', '100'),
    )

    success_rate = models.CharField(max_length=20, choices=MY_CHOICES)

    def get_absolute_url(self):
        return reverse('projects')


class Workshop(models.Model):
    # alphaSpaces = RegexValidator(r'^[a-zA-Z ]+$', 'Only letters and spaces are allowed in the Location Name.', message='Username must be Alphanumeric',code='invalid_username')

    events_name = models.CharField(max_length=500)
    instructor_name = models.CharField(max_length=500)
    event_description = models.TextField(max_length=500)
    event_feedback = models.TextField(max_length=500)
    starting_date = models.DateField(max_length=13)
    ending_date = models.DateField(max_length=13)

    MY_CHOICES = (
        ('10', '10'),
        ('20', '20'),
        ('30', '30'),
        ('40', '40'),
        ('50', '50'),
        ('60', '60'),
        ('70', '70'),
        ('80', '80'),
        ('90', '90'),
        ('100', '100'),
    )
    success_rate = models.CharField(max_length=20, choices=MY_CHOICES)

    MY_CHOICES = (
        ('Workshop', 'Workshop'),
        ('Training', 'Training'),
    )
    event_category = models.CharField(max_length=20, choices=MY_CHOICES)

    # def clean(self):
    #     cleaned_data = super(Workshop, self).clean()
    #
    #     field_1 = cleaned_data.get('field_1')
    #     field_2 = cleaned_data.get('field_2')
    #     field_3 = cleaned_data.get('field_3')
    #
    #     # Values may be None if the fields did not pass previous validations.
    #     if field_1 is not None and field_2 is not None and field_3 is not None:
    #         # If fields have values, perform validation:
    #         if not field_3 == field_1 + field_2:
    #             # Use None as the first parameter to make it a non-field error.
    #             # If you feel is related to a field, use this field's name.
    #             self.add_error(field_1, ValidationError('field_3 must be equal to the sum of field_1 and filed_2'))

    def get_absolute_url(self):
        return reverse('workshops&trainings')


# class Year(models.Model):
#
#     year = models.CharField(max_length=4)
#
#     def __str__(self):
#         return self.year

class UserForm(models.Model):
    uid = models.CharField(max_length=10)
    fid = models.CharField(max_length=10)
